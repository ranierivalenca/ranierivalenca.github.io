<?php
    // var_dump($_GET);
    echo "Você digitou: " .
        $_GET["texto-1"] . " e " .
        $_GET["texto-2"];
?>